#Version of the module

__version__ = '1.0.2'
