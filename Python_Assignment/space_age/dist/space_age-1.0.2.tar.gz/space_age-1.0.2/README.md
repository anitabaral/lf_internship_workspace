# Space Age
It takes age in earth and the planet in which you would like to know your age, and then displays the age in that specified planet.

## Installation
```pip install space_age```

## How to use it?
Open terminal and type space and then input your age in earth and then the planet where you wish to know your age.

## License

© 2021 Anita Baral

This repository is licensed under the MIT license. See LICENSE for details.
